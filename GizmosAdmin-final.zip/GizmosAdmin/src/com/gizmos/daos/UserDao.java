package com.gizmos.daos;


import java.util.Date;
import java.util.List;

import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;

public interface UserDao {
	void insertNewUser(User user) throws GizmosException;
	public void updateByEmailId(User user) throws GizmosException;
	List<User> viewAccounts() throws GizmosException;
	public List<User> searchAccountsByDateOfSignUp(Date dateOfSignUp) throws GizmosException;
	void close() throws GizmosException;
}
