package com.gizmos.daos;

import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.gizmos.entities.Orders;
import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;


@Repository("userDao")
public class UserDaoImpl implements UserDao {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void insertNewUser(User user) throws GizmosException {
		Session session=sessionFactory.openSession();
		System.out.println("User: "+user);
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.save(user);
			tn.commit();
		}catch(HibernateException ex)
		{
			if(tn != null) {
				tn.rollback();
			}
		}
		session.close();
		
	}

	

	@Override
	public void updateByEmailId(User user) throws GizmosException {
		Session session = sessionFactory.openSession();
	    String hql = "update User u set u.userFirstName =: userFirstName, u.userLastName = :userLastName, u.userAddress =: userAddress, u.userCity =: userCity, u.userZipNo =: userZipNo, u.userState =:userState, u.userMobileNo =:userMobileNo where u.userEmail = :email";
	    Query q = session.createQuery(hql);
	    q.setParameter("email", user.getUserEmail());
	    q.setParameter("userFirstName", user.getUserFirstName());
	    q.setParameter("userLastName", user.getUserLastName());
	    q.setParameter("userAddress", user.getUserAddress());
	    q.setParameter("userCity", user.getUserCity());
	    q.setParameter("userZipNo", user.getUserZipNo());
	    q.setParameter("userState", user.getUserState());
	    q.setParameter("userMobileNo", user.getUserMobileNo());
	   
	    
	    Transaction tn = session.getTransaction();
	    try {
			tn.begin();
			q.executeUpdate();
			session.flush();
			tn.commit();
		}catch(HibernateException ex)
		{
			if(tn != null) {
				tn.rollback();
			}
		}
	 
	    session.close();
		
	}
	



	@Override
	public List<User> viewAccounts() throws GizmosException {
		Session session = sessionFactory.openSession();
		String hql = "From User u";
		Query qry = session.createQuery(hql);
		List<User> list = qry.list();
		session.close();
		return list;
	}



	@Override
	public List<User> searchAccountsByDateOfSignUp(Date dateOfSignUp) throws GizmosException {
		Session session = sessionFactory.openSession();
		  Query qry = session.createQuery("FROM User u WHERE u.dateOfSignUp =: date").setParameter("date", dateOfSignUp);
		  List<User> accounts = qry.list();
		  session.close();
		  return accounts;

	}

	



    @Override
    public void close() throws GizmosException {
	// TODO Auto-generated method stub
	
    }

}
