package com.gizmos.services;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gizmos.daos.UserDao;
import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;


@Service("userServices")
public class UserServicesImpl implements UserServices {

	@Autowired
	private UserDao dao;
	
	
	@Override
	public void insertNewUser(User user) throws GizmosException {
		dao.insertNewUser(user);

	}


	@Override
	public void close() throws GizmosException {
		dao.close();
		
	}


	@Override
	public void updateByEmailId(User user) throws GizmosException {
		dao.updateByEmailId(user);
		
	}


	@Override
	public List<User> viewAccounts() throws GizmosException {
		return dao.viewAccounts();
	}


	@Override
	public List<User> searchAccountsByDateOfSignUp(Date dateOfSignUp) throws GizmosException {
		
		return dao.searchAccountsByDateOfSignUp(dateOfSignUp);
	}

}
