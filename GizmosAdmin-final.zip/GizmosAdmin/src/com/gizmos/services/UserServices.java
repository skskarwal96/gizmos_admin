package com.gizmos.services;

import java.util.Date;
import java.util.List;

import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;

public interface UserServices {
	
	void insertNewUser(User user) throws GizmosException;
	public void updateByEmailId(User user) throws GizmosException;
	public List<User> viewAccounts() throws GizmosException;
	public List<User> searchAccountsByDateOfSignUp(Date dateOfSignUp) throws GizmosException;
	public void close() throws GizmosException;
	
	
}
