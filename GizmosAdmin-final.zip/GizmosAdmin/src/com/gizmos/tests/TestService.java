package com.gizmos.tests;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.gizmos.daos.GizmosDao;
import com.gizmos.entities.Orders;
import com.gizmos.entities.Product;
import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;
import com.gizmos.services.GizmosServices;
import com.gizmos.services.OrdersServices;
import com.gizmos.services.UserServices;




public class TestService {

	public static void main(String[] args) {

		
		ApplicationContext context = new ClassPathXmlApplicationContext("productCore.xml");
		
/*		GizmosServices services = (GizmosServices) context.getBean("gizmosServices");*/
		
		/*OrdersServices oservices = (OrdersServices)  context.getBean("ordersServices");*/
		
	/*	try {
			List<Product> prodList = services.viewProduct();
			
			prodList.forEach(System.out::println);
		    } catch (GizmosException e) {
		    	e.printStackTrace();
		    }
		*/
	/*	try {
		List<Orders> orderList = oservices.viewOrders();
		orderList.forEach(System.out::println);
		}catch (GizmosException e) {
	    	e.printStackTrace();
	    }*/
		/*OrdersServices services = (OrdersServices) context.getBean("ordersServices");
		Orders orders = new Orders();*/
		
		//CRUD FOR PRODUCT TABLE
		
		GizmosServices services = (GizmosServices) context.getBean("gizmosServices");
		Product product = new Product();
		
		// 1) SEARCH PRODUCT BY PRODUCT NAME
		 
/*		try {
			List<Product> prodList = services.searchProductByName("AC1");
			
			prodList.forEach(System.out::println);
		    } catch (GizmosException e) {
		    	e.printStackTrace();
		    }*/

		
		// 2) ADD PRODUCTS IN PRODUCT TABLE
		 
			product.setProductId("RG011");
			product.setProductName("Refrigerator8");
			product.setProductPrice("69909");
			product.setProductDescription("Description goes here");
			product.setQuantity(30);
			product.setProductBrand("LG");
			product.setCategoryId("RG");
		  try {
			services.insertNewProduct(product);
		} catch (GizmosException e1) {
			e1.printStackTrace();
		} 
		
		// 3) DELETE PRODUCTS FROM PRODUCT TABLE
		 
		/*  try {
			services.deleteByProductId("RG005");
		} catch (GizmosException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		 // 4) UPDATE PRODUCTS IN PRODUCT TABLE BY PRODUCT ID
		  
		/*    product.setProductId("RG005");
			product.setProductName("xyz");
			product.setProductPrice("69999");
			product.setProductDescription("Description goes here");
			product.setQuantity(30);
			product.setProductBrand("LG");
			product.setCategoryId("RG");
		  try {
			services.updateByProductId(product);
		} catch (GizmosException e1) {
			e1.printStackTrace();
		} 
		
		// 5) SEARCH PRODUCT BY CATEGORY NAME
		
		try {
			List<Product> prodList = services.searchProductByCategory("Mobile");
			
			prodList.forEach(System.out::println);
		    } catch (GizmosException e) {
		    	e.printStackTrace();
		    }
		*/
		
/*		finally {
			
		    	try {
				services.close();
				((ConfigurableApplicationContext) context).close(); 
			    } catch (GizmosException e) {
				e.printStackTrace();
			    }
		    }
		*/

		
		//********************************************************XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX********************************************************
		
		/*UserServices services = (UserServices)context.getBean("userServices");
		User user = new User();
		
		try {
			List<User> accountsList = services.viewAccounts();
			
			accountsList.forEach(System.out::println);
		    } catch (GizmosException e) {
		    	e.printStackTrace();
		    }*/
		
		//CRUD FOR CUSTOMER TABLE
		 
		// 1) ADD NEW USER IN CUSTOMER TABLE
		  
		/*user.setUserPassword("qdfrgs");
		user.setUserFirstName("abc");
		user.setUserLastName("xyh");
		user.setUserAddress("fghjkloih");
		user.setUserCity("hjijjjh");
		user.setUserZipNo(129812);
		user.setUserState("herry");
		user.setUserMobileNo(774969699);
		String str = "12-05-2018";
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	    LocalDate dateTime = LocalDate.parse(str, formatter);

		user.setDateOfSignUp(java.sql.Date.valueOf(dateTime));
	  try {
		services.insertNewUser(user);
	} catch (GizmosException e1) {
		e1.printStackTrace();
	} 
		*/
	   // 2) UPDATE EXISTING USER PROFILE IN CUSTOMER TABLE BY EMAILID
		
		/*user.setUserEmail("shruti@gmail.com");
		user.setUserFirstName("Prachi");
		user.setUserLastName("gdhudygu");
		user.setUserAddress("kolkata");
		user.setUserCity("hjijjjh");
		user.setUserZipNo(129812);
		user.setUserState("herry");
		user.setUserMobileNo(887890959);
	  try {
			services.updateByEmailId(user);
		} catch (GizmosException e1) {
			e1.printStackTrace();
		} */
	  
	/*  finally {
			
	    	try {
			services.close();
			((ConfigurableApplicationContext) context).close(); 
		    } catch (GizmosException e) {
			e.printStackTrace();
		    }

		}
	  */
	  
//***********************************************************************************************************	  
	//1) VIEW ORDERS TABLE
		
	/* try {
			List<Orders> orderList = services.viewOrders();
			
			orderList.forEach(System.out::println);
		    } catch (GizmosException e) {
		    	e.printStackTrace();
		    }*/
	 
	/* String str = "12-06-2009";
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	    LocalDate dateTime = LocalDate.parse(str, formatter);
	    orders.setDateOfPurchase(java.sql.Date.valueOf(dateTime));
	  try {
		
		List<Orders> orderList = services.searchOrdersByDateOfPurchase(orders.getDateOfPurchase());
		
		orderList.forEach(System.out::println);
	} catch (GizmosException e1) {
		e1.printStackTrace();
	} */
	 
	  
	  
	  finally {
		
    	try {
		services.close();
		((ConfigurableApplicationContext) context).close(); 
	    } catch (GizmosException e) {
		e.printStackTrace();
	    }

	}
	}
}
	
	


