package com.gizmos.exceptions;

public class GizmosException extends Exception {

	private static final long serialVersionUID = 1L;

	public GizmosException(String message, Throwable cause) {
		super(message, cause);
	}

	public GizmosException(String message) {
		super(message);
	}

	
}
