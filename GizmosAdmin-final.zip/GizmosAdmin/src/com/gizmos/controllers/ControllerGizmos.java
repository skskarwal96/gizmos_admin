package com.gizmos.controllers;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.gizmos.entities.Orders;
import com.gizmos.entities.Product;
import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;
import com.gizmos.services.GizmosServices;
import com.gizmos.services.OrdersServices;
import com.gizmos.services.UserServices;

@RestController
public class ControllerGizmos {
	
	@Autowired
	GizmosServices services;
	
	@Autowired
	OrdersServices oservices;
	@Autowired
	UserServices uservices;
	
	@RequestMapping(value="/viewProduct", method = RequestMethod.GET, headers="Accept=application/json")
	public List<Product> getProductList(Model model) throws GizmosException {
		
		List<Product> prodList = services.viewProduct();
		System.out.println(prodList);
		return prodList;
	}	
	
	
	@RequestMapping(value="/viewOrder", method = RequestMethod.GET, headers="Accept=application/json")
	public List<Orders> getOrderList(Model model) throws GizmosException {
		
		System.out.println("in controller");
		List<Orders> orderList = oservices.viewOrders();
		System.out.println(orderList);
		return orderList;
	}
	
	@RequestMapping(value="/viewUser", method = RequestMethod.GET, headers="Accept=application/json")
	public List<User> getUserList(Model model) throws GizmosException {
		
		System.out.println("in controller");
		List<User> userList = uservices.viewAccounts();
		System.out.println(userList);
		return userList;
	}
	

	@RequestMapping(value="/delete/{id}",method = RequestMethod.DELETE, headers="Accept=application/json")
	public List<Product> deleteProduct(@PathVariable String id) throws GizmosException {
		System.out.println("in controller");
		System.out.println("Id " + id);
		services.deleteByProductId(id);
		return services.viewProduct();
	}
	
	@RequestMapping(value = "/create/{id}/{name}/{price}/{desc}/{quant}/{brand}/{pic}/{catId}",
			headers="Accept=application/json", method = RequestMethod.POST)
	public List<Product> createProduct(@PathVariable String id,@PathVariable String name,@PathVariable String price
			,@PathVariable String desc,@PathVariable int quant,@PathVariable String brand, @PathVariable String pic,@PathVariable String catId) throws GizmosException {
		System.out.println("in add.java");
		
		Product p=new Product();
		p.setProductId(id);
		p.setProductName(name);
		p.setProductPrice(price);
		p.setProductDescription(desc);
		p.setQuantity(quant);
		p.setProductBrand(brand);
		p.setProductPic(pic);
		p.setCategoryId(catId);
		
		
		services.insertNewProduct(p);
		System.out.println(p);
	
		return services.viewProduct();
	}
	
	@RequestMapping(value="/searchOrder/{date}", method = RequestMethod.GET, headers="Accept=application/json")
	public List<Orders> searchOrderByDate(@PathVariable String date) throws GizmosException {
		
		System.out.println("in controller");
		String startDateString = date;
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy"); 
		Date startDate = null;
		    try {
				startDate = df.parse(startDateString);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    String newDateString = df.format(startDate);
	    
		List<Orders> orderList = oservices.searchOrdersByDateOfPurchase(startDate);
		System.out.println(orderList);
		return orderList;
	}
	
	@RequestMapping(value="/searchUser/{date}", method = RequestMethod.GET, headers="Accept=application/json")
	public List<User> searchUserByDate(@PathVariable String date) throws GizmosException {
		
		System.out.println("in controller");
		String startDateString = date;
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy"); 
		Date startDate = null;
		    try {
				startDate = df.parse(startDateString);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    String newDateString = df.format(startDate);
		    
		List<User> userList = uservices.searchAccountsByDateOfSignUp(startDate);
		System.out.println(userList);
		return userList;
	}
	
	
	

	
//	@RequestMapping(value="/viewProductByName/{name}", method = RequestMethod.GET, headers="Accept=application/json")
//	public List<Product> getProductByName(@PathVariable String name) throws GizmosException {
//		
//		System.out.println(name);
//		List<Product> product = services.searchProductByName(name);
//		System.out.println(product);
//		return product;
//	
//	}
//	
//	
//	@RequestMapping("viewProductByCategory")
//	public ModelAndView getProductByCategory() throws GizmosException {
//
//		List<Product> product = services.searchProductByCategory("Laptop");
//		
//		ModelAndView mAndV = new ModelAndView("getProductByCategory");
//		
//		mAndV.addObject("product", product);
//		
//		mAndV.addObject("pageTitle", "Details of Product");
//		
//		return mAndV;
//	
//	}
}
