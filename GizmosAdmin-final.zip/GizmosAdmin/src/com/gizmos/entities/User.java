package com.gizmos.entities;


import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.format.annotation.DateTimeFormat;

@Entity(name="User")
@Table(name="CUSTOMER")
@GenericGenerator(name = "SequenceStringGenerator", strategy = "com.gizmos.entities.UserIdGenerator", parameters = {
        @org.hibernate.annotations.Parameter(name = "sequenceName", value = "UserIdSeq" ),
})
public class User{
	
	private String userId;
	private String userPassword;
	private String userFirstName;
	private String userLastName;
    private String userAddress;
    private String userCity;
    private int userZipNo;
    private String userState;
    private long userMobileNo;
    private String userEmail;
    private Date dateOfSignUp;
    
    
    public User() {
		super();
	}
    
   
    
    public User(String userId, String userPassword, String userFirstName, String userLastName, String userAddress,
			String userCity, int userZipNo, String userState, long userMobileNo, String userEmail,
			Date dateOfSignUp) {
		super();
		this.userId = userId;
		this.userPassword = userPassword;
		this.userFirstName = userFirstName;
		this.userLastName = userLastName;
		this.userAddress = userAddress;
		this.userCity = userCity;
		this.userZipNo = userZipNo;
		this.userState = userState;
		this.userMobileNo = userMobileNo;
		this.userEmail = userEmail;
		this.dateOfSignUp = dateOfSignUp;
	}

   /* public String getSequencePrefix(String userId){
    	
        String temp = "TEMP";
        if(userId.length()<6){
            int zeroCount = 6 - userId.length();

            for(int index=0;index<zeroCount;index++){
                temp = temp + "0";
            }
        }
        return temp;
    }*/
	
    @Id
    /*@GenericGenerator(
            name = "assigned-sequence",
            strategy = "com.vladmihalcea.book.hpjp.hibernate.identifier.StringSequenceIdentifier",
            parameters = {
                @org.hibernate.annotations.Parameter(
                    name = "sequence_name", value = "seq_1"),
                @org.hibernate.annotations.Parameter(
                    name = "sequence_prefix", value = "User"),
            }
        )
        @GeneratedValue(
            generator = "assigned-sequence", 
            strategy = GenerationType.SEQUENCE)*/
	@Column(name = "USERID")
    @GeneratedValue(generator = "SequenceStringGenerator")
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(name="UPASS")
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	@Column(name="FNAME")
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	 @Column(name="LNAME")
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	 @Column(name="ADDR")
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	 @Column(name="CITY")
	public String getUserCity() {
		return userCity;
	}
	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	 @Column(name="ZIPNO")
	public int getUserZipNo() {
		return userZipNo;
	}
	public void setUserZipNo(int userZipNo) {
		this.userZipNo = userZipNo;
	}

	 @Column(name="STATE")
	public String getUserState() {
		return userState;
	}
	public void setUserState(String userState) {
		this.userState = userState;
	}

	@Column(name="MBL")
	public long getUserMobileNo() {
		return userMobileNo;
	}
	public void setUserMobileNo(long userMobileNo) {
		this.userMobileNo = userMobileNo;
	}

	@Column(name="EML")
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	@DateTimeFormat(pattern = "dd-MM-yyyy")
    @Column(name="DATEINS")
	public Date getDateOfSignUp() {
		return dateOfSignUp;
	}
	public void setDateOfSignUp(Date dateOfSignUp) {
		this.dateOfSignUp = dateOfSignUp;
	}


	@Override
	public String toString() {
		return "User [userId=" + userId + ", userPassword=" + userPassword + ", userFirstName=" + userFirstName
				+ ", userLastName=" + userLastName + ", userAddress=" + userAddress + ", userCity=" + userCity
				+ ", userZipNo=" + userZipNo + ", userState=" + userState + ", userMobileNo=" + userMobileNo
				+ ", userEmail=" + userEmail + ", dateOfSignUp=" + dateOfSignUp + "]";
	}

	/*public String getSequencePrefix(String userId){
        String temp = "TEMP";
        if(userId.length()<6){
            int zeroCount = 6 - userId.length();

            for(int index=0;index<zeroCount;index++){
                temp = temp + "0";
            }
        }
        return temp;
    }*/
    
    
}
