package com.gizmos.entities;

import javax.persistence.*;


@Entity(name="Customer")
@Table(name="CUSTOMER")
public class Customer {

	@Id
	@Column(name="userid")
	private String userId;
	
	@Column(name="upass")
	private String uPass;
	
	@Column(name="fname")
	private String fName;
	
	@Column(name="lname")
	private String lName;
	
	@Column(name="addr")
	private String addr;
	
	@Column(name="city")
	private String city;
	
	@Column(name="zipno")
	private int zipNo;
	
	@Column(name="state")
	private String state;
	
	@Column(name="mbl")
	private long mbl;
	
	@Column(name="eml")
	private String eml;
	
	@Column(name="dateins")
	private String dateIns;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getuPass() {
		return uPass;
	}

	public void setuPass(String uPass) {
		this.uPass = uPass;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZipNo() {
		return zipNo;
	}

	public void setZipNo(int zipNo) {
		this.zipNo = zipNo;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public long getMbl() {
		return mbl;
	}

	public void setMbl(long mbl) {
		this.mbl = mbl;
	}

	public String getEml() {
		return eml;
	}

	public void setEml(String eml) {
		this.eml = eml;
	}

	public String getDateIns() {
		return dateIns;
	}

	public void setDateIns(String dateIns) {
		this.dateIns = dateIns;
	}

	public Customer() {
		super();
	}
	
	public Customer(String userId, String uPass, String fName, String lName, String addr, String city, int zipNo,
			String state, long mbl, String eml, String dateIns) {

		this.userId = userId;
		this.uPass = uPass;
		this.fName = fName;
		this.lName = lName;
		this.addr = addr;
		this.city = city;
		this.zipNo = zipNo;
		this.state = state;
		this.mbl = mbl;
		this.eml = eml;
		this.dateIns = dateIns;
	}

	
	@Override
	public String toString() {
		return "Customer [userId=" + userId + ", uPass=" + uPass + ", fName=" + fName + ", lName=" + lName + ", addr="
				+ addr + ", city=" + city + ", zipNo=" + zipNo + ", state=" + state + ", mbl=" + mbl + ", eml=" + eml
				+ ", dateIns=" + dateIns + "]";
	}
	
}
