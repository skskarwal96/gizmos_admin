package com.gizmos.entities;


import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.format.annotation.DateTimeFormat;
import java.text.*;


@Entity(name="User")
@Table(name="CUSTOMER")
@GenericGenerator(name = "SequenceStringGenerator", strategy = "com.gizmos.entities.UserIdGenerator", parameters = {
        @org.hibernate.annotations.Parameter(name = "sequenceName", value = "UserIdSeq" ),
})
public class User{
	@Id
	@Column(name = "USERID")
	@GeneratedValue(generator = "SequenceStringGenerator")
	private String userId;
	@Column(name="UPASS")
	private String userPassword;
	@Column(name="FNAME")
	private String userFirstName;
	@Column(name="LNAME")
	private String userLastName;
	@Column(name="ADDR")
    private String userAddress;
	@Column(name="CITY")
    private String userCity;
	@Column(name="ZIPNO")
    private int userZipNo;
	@Column(name="STATE")
    private String userState;
	@Column(name="MBL")
    private long userMobileNo;
	@Column(name="EML")
    private String userEmail;
	@DateTimeFormat(pattern = "dd-MM-yyyy")
    @Column(name="DATEINS")
    private Date dateOfSignUp;
    
    
    public User() {
		super();
	}
    
    public User(String userId, String userPassword, String userFirstName, String userLastName, String userAddress,
			String userCity, int userZipNo, String userState, long userMobileNo, String userEmail, Date dateOfSignUp) {
		super();
		this.userId = userId;
		this.userPassword = userPassword;
		this.userFirstName = userFirstName;
		this.userLastName = userLastName;
		this.userAddress = userAddress;
		this.userCity = userCity;
		this.userZipNo = userZipNo;
		this.userState = userState;
		this.userMobileNo = userMobileNo;
		this.userEmail = userEmail;
		this.dateOfSignUp = dateOfSignUp;
	}

	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public String getUserFirstName() {
		return userFirstName;
	}


	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}


	public String getUserLastName() {
		return userLastName;
	}


	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}


	public String getUserAddress() {
		return userAddress;
	}


	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}


	public String getUserCity() {
		return userCity;
	}


	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}


	public int getUserZipNo() {
		return userZipNo;
	}


	public void setUserZipNo(int userZipNo) {
		this.userZipNo = userZipNo;
	}


	public String getUserState() {
		return userState;
	}


	public void setUserState(String userState) {
		this.userState = userState;
	}


	public long getUserMobileNo() {
		return userMobileNo;
	}


	public void setUserMobileNo(long userMobileNo) {
		this.userMobileNo = userMobileNo;
	}


	public String getUserEmail() {
		return userEmail;
	}


	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	public Date getDateOfSignUp() {
		return dateOfSignUp;
	}


	public void setDateOfSignUp(Date dateOfSignUp) {
		this.dateOfSignUp = dateOfSignUp;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userPassword=" + userPassword + ", userFirstName=" + userFirstName
				+ ", userLastName=" + userLastName + ", userAddress=" + userAddress + ", userCity=" + userCity
				+ ", userZipNo=" + userZipNo + ", userState=" + userState + ", userMobileNo=" + userMobileNo
				+ ", userEmail=" + userEmail + ", dateOfSignUp=" + dateOfSignUp + "]";
	}
    
   
    
    
    
    
}
