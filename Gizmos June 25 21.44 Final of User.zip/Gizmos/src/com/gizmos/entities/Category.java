package com.gizmos.entities;

import javax.persistence.*;


@Entity(name="Category")
@Table(name="CATEGORY")
public class Category {
	
	@Id
	@Column(name="catid")
	private String categoryId;
	
	@Column(name="catname")
	private String categoryName;
	
	
	public Category() {
		super();
	}
	
	
	public Category(String categoryId, String categoryName) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}
	
	
	public String getCategoryId() {
		return categoryId;
	}
	
	
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	
	
	public String getCategoryName() {
		return categoryName;
	}
	
	
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + "]";
	}
	
	
}
