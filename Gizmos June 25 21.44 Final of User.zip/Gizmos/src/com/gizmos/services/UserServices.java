package com.gizmos.services;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;

public interface UserServices {
	
	void insertNewUser(User user) throws GizmosException;
	public void updateByEmailId(User user) throws GizmosException;
	public ArrayList<User> viewAccounts() throws GizmosException;
	public List<User> searchAccountsByDateOfSignUp(Date dateOfSignUp) throws GizmosException;
	public User authenticateUser(String email , String password) throws GizmosException;	
	public List<User> getCustomerData(String email) throws GizmosException;
	public void close() throws GizmosException;
	
}
