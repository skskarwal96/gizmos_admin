package com.gizmos.tests;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.gizmos.entities.Customer;
import com.gizmos.entities.Product;
import com.gizmos.entities.Specifications;
import com.gizmos.entities.User;
import com.gizmos.exceptions.GizmosException;
import com.gizmos.services.GizmosServices;
import com.gizmos.services.UserServices;


public class TestService {

	public static void main(String[] args) {

		
		ApplicationContext context = new ClassPathXmlApplicationContext("productCore.xml");
		
		GizmosServices services = (GizmosServices) context.getBean("gizmosServices");
		
//		try {
//			List<Product> prodList = services.searchProductByName("AC1");
//			
//			prodList.forEach(System.out::println);
//		    } catch (GizmosException e) {
//		    	e.printStackTrace();
//		    }
//		try {
//			List<Product> prodList = services.searchProductByCategory("Mobile");
//			
//			prodList.forEach(System.out::println);
//		    } catch (GizmosException e) {
//		    	e.printStackTrace();
//		    }
//		try {
//			List<Customer> prodList = services.viewCustomer();
//			
//			prodList.forEach(System.out::println);
//		    } catch (GizmosException e) {
//		    	e.printStackTrace();
//		    }
		
		UserServices uservices = (UserServices)context.getBean("userServices");
		
		//AUTHENTICATION OF USER
//		try {
//		 User account = uservices.authenticateUser("neha@gmail.com","Hello23");
//		 if(account != null) {
//		        System.out.println("Login successful");
//	 
//		 }
//	 
//		 else {
//	            System.out.println("Account does not exist");
//	        }
//		
//		} catch (GizmosException e) {
//			
//			e.printStackTrace();
//		}
		try {
		List<Specifications> userdata = services.viewSpecifications("MB001");
		System.out.println(userdata);
		}catch (GizmosException e) {
	
	e.printStackTrace();
	}
		finally {
			
		    	try {
				services.close();
				((ConfigurableApplicationContext) context).close(); 
			    } catch (GizmosException e) {
				e.printStackTrace();
			    }
		    }
	}

	}


