


function checkPass() {
           
    var pass1 = document.getElementById('pass1');
    var pass2 = document.getElementById('pass2');
    
    var message = document.getElementById('confirmMessage');
   
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
  
    if (pass1.value == pass2.value) {
        
        pass2.style.backgroundColor = goodColor;
        message.style.color = goodColor;
        message.innerHTML = "Password Match"
    } else {
        
        pass2.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "Password Doesn't Match"
    }
}



window.onclick = function (event) {
    if (event.target == document.getElementById('login')) {
        $('#login').find('input[type=password], input[type=email]').val('');
        document.getElementById('login').style.display = "none";
        document.getElementById('back').style.position = "relative";
        document.getElementById('dots').style.zIndex='1';
        
        
        
       
    }
    else
        if ( event.target == document.getElementById('forget_password')) {
            $('#forget_password').find('input[type=email]').val('');
            document.getElementById('forget_password').style.display = "none";
            document.getElementById('back').style.position = "relative";
            document.getElementById('dots').style.zIndex='1';
            
            
           
        }
    if (event.target == document.getElementById('signup')) {
        $('#signup').find('input[type=text], input[type=password], input[type=email]').val('');
    document.getElementById('pass2').style.backgroundColor='#ffffff';
    $('.confirmMessage').remove();
        document.getElementById('signup').style.display = "none";
        document.getElementById('back').style.position = "relative";
         document.getElementById('dots').style.zIndex='1';
    }
}

function login_signup(i) {
    
    if (i === 1) {
       
        document.getElementById('login').style.display = 'block';
         document.getElementById('back').style.position = "fixed";
         document.getElementById('dots').style.zIndex='-1';     

    }
    if (i === 2) {
        document.getElementById('login').style.display = 'none';
        document.getElementById('signup').style.display = 'block';
        //  
        document.getElementById('back').style.position = "fixed";
        

    }
    if (i === 3) {
        document.getElementById('login').style.display = 'block';
        document.getElementById('signup').style.display = 'none';
        //  
        document.getElementById('back').style.position = "fixed";
        

    }
    
}

function login_close() {   //Closing the Modal and setting the position of previous modal to relative
  
    $('#login').find('input[type=password], input[type=email]').val('');
    document.getElementById('login').style.display = 'none';
    document.getElementById('back').style.position = "relative";
    // console.log($("form").validate().settings.rules);
    document.getElementById('dots').style.zIndex='1';
    // $('#login').rules( "remove" );
    // $('input, select, textarea').each(function() {
    //     $(this).rules('remove', 'required');
    // });
}

function signup_close() {
    $('#signup').find('input[type=text], input[type=password], input[type=email]').val('');
    document.getElementById('pass2').style.backgroundColor='#ffffff';
    $('.confirmMessage').remove();
    document.getElementById('signup').style.display = 'none';
    document.getElementById('back').style.position = "relative";
    document.getElementById('dots').style.zIndex='1';
    
    

}
function forget_password_open() {
    document.getElementById('login').style.display = 'none';
    document.getElementById('forget_password').style.display = 'block';
    document.getElementById('back').style.position = "fixed";
    
    
    
}
function forget_password_close() {
    $('#forget_password').find('input[type=email]').val('');
    document.getElementById('forget_password').style.display = 'none';
    document.getElementById('back').style.position = "relative";
    document.getElementById('dots').style.zIndex='1';
    
}
