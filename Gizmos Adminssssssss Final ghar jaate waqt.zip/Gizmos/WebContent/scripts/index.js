
$(document).ready(function(){
   $(window).scrollTop(0,0);
});

