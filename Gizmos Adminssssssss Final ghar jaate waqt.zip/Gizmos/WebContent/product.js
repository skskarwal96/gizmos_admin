
var myWebservice=angular.module("myApp",[]);

	myWebservice.controller("ProductNameController",function($scope, $http) {
		
		$scope.prodname = "";

		$scope.productByName=function(){
			alert('value' + $scope.prodname)

			$http({
				method:'GET',
				url:'http://localhost:8081/Gizmos/product/viewProductByName/'+$scope.prodname
			}).success(function(data)
					{
						alert('data received' + data)
						$scope.productByName1 = data;
					});
		}
	
});

