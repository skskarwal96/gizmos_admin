package com.gizmos.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="Specifications")
@Table(name="SPECIFICATIONS")
public class Specifications {

	@Id
	@Column(name="sid")
	private int sid;
	@Column(name="catid")
	private String categoryId;
	
	@Column(name="prodid")
	private String productId;
	
	@Column(name="specs")
	private String specifications;
	
	@Column(name="value")
	private String value;
	
	@Column(name="unit")
	private String units;

	public Specifications() {
		super();
	}

	public Specifications(int sid, String categoryId, String productId, String specifications, String value,
			String units) {
		super();
		this.sid = sid;
		this.categoryId = categoryId;
		this.productId = productId;
		this.specifications = specifications;
		this.value = value;
		this.units = units;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getSpecifications() {
		return specifications;
	}

	public void setSpecifications(String specifications) {
		this.specifications = specifications;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	@Override
	public String toString() {
		return "Specifications [sid=" + sid + ", categoryId=" + categoryId + ", productId=" + productId
				+ ", specifications=" + specifications + ", value=" + value + ", units=" + units + "]";
	}

	
}
